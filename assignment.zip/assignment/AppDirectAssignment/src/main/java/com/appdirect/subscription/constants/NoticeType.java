package com.appdirect.subscription.constants;

public enum NoticeType {
	UPCOMING_INVOICE, DEACTIVATED, REACTIVATED, CLOSED;
}
