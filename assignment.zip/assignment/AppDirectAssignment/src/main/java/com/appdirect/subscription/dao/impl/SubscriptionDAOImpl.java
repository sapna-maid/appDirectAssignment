package com.appdirect.subscription.dao.impl;

import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.appdirect.subscription.constants.SubscriptionConstants;
import com.appdirect.subscription.dao.SubscriptionDAO;
import com.appdirect.subscription.orm.Company;
import com.appdirect.subscription.orm.Creater;
import com.appdirect.subscription.orm.GenericORM;
import com.appdirect.subscription.orm.MarketPlace;
import com.appdirect.subscription.orm.Order;
import com.appdirect.subscription.orm.Subscription;

@Repository
public class SubscriptionDAOImpl extends GenericDAOImpl implements SubscriptionDAO {
	private SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	@Transactional
	public int saveCompany(Company company) {
		Session session = sessionFactory.getCurrentSession();
		Integer companyId = (Integer) session.save(company);
		return companyId;
	}

	@Override
	@Transactional
	public GenericORM getEntity(int entityId, String entity) {
		Session session = sessionFactory.getCurrentSession();
		GenericORM genericORM = null;
		Criteria criteria = null;
		if (StringUtils.hasText(entity)) {
			if (SubscriptionConstants.ORDER.equals(entity)) {
				criteria = session.createCriteria(Order.class);
				criteria.add(Restrictions.eq("orderId", entityId));
			}
			if (SubscriptionConstants.MARKET_PLACE.equals(entity)) {
				criteria = session.createCriteria(MarketPlace.class);
				criteria.add(Restrictions.eq("marketplaceId", entityId));
			}
			if (SubscriptionConstants.COMPANY.equals(entity)) {
				criteria = session.createCriteria(Company.class);
				criteria.add(Restrictions.eq("companyId", entityId));
			}
			if (SubscriptionConstants.CREATER.equals(entity)) {
				criteria = session.createCriteria(Creater.class);
				criteria.add(Restrictions.eq("createrId", entityId));
			}
			if (SubscriptionConstants.SUBSCRIPTION.equals(entity)) {
				criteria = session.createCriteria(Subscription.class);
				criteria.add(Restrictions.eq("subscriptionId", entityId));
			}
			genericORM = (GenericORM) criteria.list();
		}

		return genericORM;
	}

}
