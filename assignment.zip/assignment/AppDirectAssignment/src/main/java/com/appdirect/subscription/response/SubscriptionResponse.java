package com.appdirect.subscription.response;

public class SubscriptionResponse extends APIResponse {

	private static final long serialVersionUID = 1L;

	private String accountIdentifier;
	private String errorCode;
	private String message;

	public SubscriptionResponse() {
		super();
	}

	public SubscriptionResponse(String accountIdentifier, boolean success, String errorCode,
			String message) {
		super();
		this.accountIdentifier = accountIdentifier;
		this.errorCode = errorCode;
		this.message = message;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getAccountIdentifier() {
		return accountIdentifier;
	}

	public void setAccountIdentifier(String accountIdentifier) {
		this.accountIdentifier = accountIdentifier;
	}

}
