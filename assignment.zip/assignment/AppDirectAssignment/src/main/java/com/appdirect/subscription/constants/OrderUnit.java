package com.appdirect.subscription.constants;

public enum OrderUnit {
	USER
}
