package com.appdirect.subscription.dao;

import com.appdirect.subscription.orm.GenericORM;

public interface GenericDAO {

	public <T> int save(T object);

	public <T> void delete(T object);

	GenericORM getEntity(int entityId, String entity);

}
