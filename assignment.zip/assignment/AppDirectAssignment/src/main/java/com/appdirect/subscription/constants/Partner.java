package com.appdirect.subscription.constants;

public enum Partner {
	APPDIRECT;
}
