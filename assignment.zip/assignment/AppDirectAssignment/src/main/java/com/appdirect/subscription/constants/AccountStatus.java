package com.appdirect.subscription.constants;

public enum AccountStatus {
	ACTIVE, INACTIVE;

}
