package com.appdirect.subscription.request;

import java.io.Serializable;

import com.appdirect.subscription.constants.Partner;

public class MarketplaceRequest implements Serializable {

	private static final long serialVersionUID = 1L;
	private String baseUrl;
	private Partner partner;

	public String getBaseUrl() {
		return baseUrl;
	}

	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}

	public Partner getPartner() {
		return partner;
	}

	public void setPartner(Partner partner) {
		this.partner = partner;
	}

}
