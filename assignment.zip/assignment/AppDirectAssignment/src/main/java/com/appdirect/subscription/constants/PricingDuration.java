package com.appdirect.subscription.constants;

public enum PricingDuration {
	MONTHLY,YEARLY
}
