package com.appdirect.subscription.dao;

import com.appdirect.subscription.orm.Company;

public interface SubscriptionDAO extends GenericDAO {

	int saveCompany(Company company);

}
