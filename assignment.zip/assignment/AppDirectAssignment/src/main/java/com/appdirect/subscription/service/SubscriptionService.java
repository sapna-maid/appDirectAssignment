package com.appdirect.subscription.service;

import com.appdirect.subscription.exception.SubscritonException;
import com.appdirect.subscription.request.SubscriptionCancelRequest;
import com.appdirect.subscription.request.SubscriptionCreateRequest;
import com.appdirect.subscription.response.APIResponse;
import com.appdirect.subscription.response.SubscriptionResponse;

public interface SubscriptionService {

	SubscriptionResponse createSubscription(SubscriptionCreateRequest subscriptionCreateRequest)
			throws SubscritonException;

	SubscriptionResponse updateSubscription(SubscriptionCreateRequest subscriptionCreateRequest)
			throws SubscritonException;

	APIResponse cancelSubscription(SubscriptionCancelRequest subscriptionCancelRequest)
			throws SubscritonException;

}
