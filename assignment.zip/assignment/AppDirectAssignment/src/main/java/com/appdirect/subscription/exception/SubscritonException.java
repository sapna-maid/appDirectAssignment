package com.appdirect.subscription.exception;

import java.util.List;

public class SubscritonException extends Exception {

	private static final long serialVersionUID = 1L;

	public SubscritonException(String error) {
		super();
		this.error = error;
		System.out.println("Exception: " + error);
	}

	public SubscritonException(List<String> errors) {
		this.errors = errors;
		if (null != errors && errors.size() > 0) {
			for (String error : errors) {
				System.out.println("exception: " + error);
			}
		}

	}
	private String error;
	private List<String> errors;

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public List<String> getErrors() {
		return errors;
	}

	public void setErrors(List<String> errors) {
		this.errors = errors;
	}

}
