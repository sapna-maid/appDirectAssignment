package com.appdirect.subscription.orm;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.appdirect.subscription.constants.OrderUnit;
import com.appdirect.subscription.constants.PricingDuration;

@Entity
@Table(name = "order")
public class Order implements GenericORM {
	@Id
	@GeneratedValue
	@Column(name = "order_id")
	private Integer orderId;

	@Column(name = "edition_code")
	private String editionCode;

	@Column(name = "pricing_duration")
	private PricingDuration pricingDuration;

	@Column(name = "unit")
	private OrderUnit unit;

	@Column(name = "item_quantity")
	private Integer item_quantity;

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public String getEditionCode() {
		return editionCode;
	}

	public void setEditionCode(String editionCode) {
		this.editionCode = editionCode;
	}

	public PricingDuration getPricingDuration() {
		return pricingDuration;
	}

	public void setPricingDuration(PricingDuration pricingDuration) {
		this.pricingDuration = pricingDuration;
	}

	public OrderUnit getUnit() {
		return unit;
	}

	public void setUnit(OrderUnit unit) {
		this.unit = unit;
	}

	public Integer getItem_quantity() {
		return item_quantity;
	}

	public void setItem_quantity(Integer item_quantity) {
		this.item_quantity = item_quantity;
	}

}
