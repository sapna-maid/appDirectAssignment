package com.appdirect.subscription.response;

import java.io.Serializable;

public class APIResponse implements Serializable {

	private static final long serialVersionUID = 1L;

	public APIResponse() {
		this.success = true;
	}

	public APIResponse(boolean success) {
		super();
		this.success = success;
	}

	private boolean success;

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

}
