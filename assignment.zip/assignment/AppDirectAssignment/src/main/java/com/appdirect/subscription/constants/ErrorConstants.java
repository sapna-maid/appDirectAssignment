package com.appdirect.subscription.constants;

public class ErrorConstants {

	public static final String USER_EXISTS = "USER_ALREADY_EXISTS";
}
