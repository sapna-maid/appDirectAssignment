package com.appdirect.subscription.orm;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.appdirect.subscription.constants.SubscriptionEvent;

@Entity
@Table(name = "subscription")
public class Subscription implements GenericORM {

	@Id
	@GeneratedValue
	@Column(name = "subscription_id")
	private Integer subscriptionId;

	@Column(name = "type")
	private SubscriptionEvent type;

	@OneToOne
	@JoinColumn(name = "order_id", referencedColumnName = "order_id")
	private Order order;

	@OneToOne
	@JoinColumn(name = "marketplace_id", referencedColumnName = "marketplace_id")
	private MarketPlace marketPlace;

	@OneToOne
	@JoinColumn(name = "creater_id", referencedColumnName = "creater_id")
	private Creater creator;

	@OneToOne
	@JoinColumn(name = "company_id", referencedColumnName = "company_id")
	private Company company;

	public Integer getSubscriptionId() {
		return subscriptionId;
	}

	public void setSubscriptionId(Integer subscriptionId) {
		this.subscriptionId = subscriptionId;
	}

	public SubscriptionEvent getType() {
		return type;
	}

	public void setType(SubscriptionEvent type) {
		this.type = type;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public MarketPlace getMarketPlace() {
		return marketPlace;
	}

	public void setMarketPlace(MarketPlace marketPlace) {
		this.marketPlace = marketPlace;
	}

	public Creater getCreator() {
		return creator;
	}

	public void setCreator(Creater creator) {
		this.creator = creator;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

}
