package com.appdirect.subscription.orm;

public interface GenericORM {

}
