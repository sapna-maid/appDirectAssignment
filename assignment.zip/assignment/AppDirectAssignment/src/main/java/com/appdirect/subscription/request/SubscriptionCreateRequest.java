package com.appdirect.subscription.request;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.appdirect.subscription.constants.SubscriptionError;
import com.appdirect.subscription.constants.SubscriptionEvent;
import com.appdirect.subscription.exception.SubscritonException;
import com.appdirect.subscription.request.CompanyOrderRequest.Company;
import com.appdirect.subscription.request.CompanyOrderRequest.Order;
import com.appdirect.subscription.request.CompanyOrderRequest.Order.Item;

public class SubscriptionCreateRequest extends APIRequest {

	private static final long serialVersionUID = 1L;
	private SubscriptionEvent type;
	private CreatorRequest creator;

	private MarketplaceRequest marketplace;

	private CompanyOrderRequest payload;

	public SubscriptionEvent getType() {
		return type;
	}

	public void setType(SubscriptionEvent type) {
		this.type = type;
	}

	public CreatorRequest getCreator() {
		return creator;
	}

	public void setCreator(CreatorRequest creator) {
		this.creator = creator;
	}

	public MarketplaceRequest getMarketplace() {
		return marketplace;
	}

	public void setMarketplace(MarketplaceRequest marketplace) {
		this.marketplace = marketplace;
	}

	public CompanyOrderRequest getPayload() {
		return payload;
	}

	public void setPayload(CompanyOrderRequest payload) {
		this.payload = payload;
	}

	@Override
	public void validate() throws SubscritonException {
		List<String> errors = new ArrayList<String>();
		switch (this.getType()) {
		case SUBSCRIPTION_ORDER:
			if (null == this.getPayload() || null == this.getPayload().getCompany()) {
				errors.add(SubscriptionError.COMPANY_PAYLOAD_REQUITRED);
			}
			break;
		case SUBSCRIPTION_CANCEL:
			break;
		case SUBSCRIPTION_CHANGE:
			break;
		case SUBSCRIPTION_NOTICE:
			break;
		default:
			break;
		}
		if(null != errors && errors.size() > 0) {
			throw new SubscritonException(errors);
		}
	}
	
	
	public static void main(String a[]) throws JsonGenerationException, JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		SubscriptionCreateRequest request = new SubscriptionCreateRequest();
		CreatorRequest createrReq = new CreatorRequest();
		CompanyOrderRequest orderReq = new CompanyOrderRequest();
		
		Company company = orderReq.new Company();
		orderReq.setCompany(company);
		
		Order order = orderReq.new Order();
		Item item  = order.new Item();
		order.setItem(item);
		orderReq.setOrder(order);
		
		
	
		request.setCreator(createrReq);
		request.setPayload(orderReq);
		System.out.println(mapper.writeValueAsString(request));
		
	}

}
