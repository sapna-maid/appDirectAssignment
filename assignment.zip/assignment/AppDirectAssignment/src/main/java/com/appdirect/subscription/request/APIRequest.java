package com.appdirect.subscription.request;

import java.io.Serializable;

import com.appdirect.subscription.exception.SubscritonException;

public class APIRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	public void validate() throws SubscritonException {
	}

}
