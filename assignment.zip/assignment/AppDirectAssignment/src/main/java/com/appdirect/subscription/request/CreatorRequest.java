package com.appdirect.subscription.request;

import java.io.IOException;
import java.io.Serializable;

import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.appdirect.subscription.constants.Language;
import com.appdirect.subscription.exception.SubscritonException;

public class CreatorRequest extends APIRequest {

	private static final long serialVersionUID = 1L;

	public class Address implements Serializable {
		private static final long serialVersionUID = 1L;
		private String firstName;
		private String fullName;
		private String lastName;

		public String getFirstName() {
			return firstName;
		}

		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}

		public String getFullName() {
			return fullName;
		}

		public void setFullName(String fullName) {
			this.fullName = fullName;
		}

		public String getLastName() {
			return lastName;
		}

		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
	}

	private Address addr;

	public Address getAddr() {
		return addr;
	}

	public void setAddr(Address addr) {
		this.addr = addr;
	}

	private String email;
	private String firstName;
	private Language language;
	private String lastName;
	private String locale;
	private String openId;
	private String uuid;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Language getLanguage() {
		return language;
	}

	public void setLanguage(Language language) {
		this.language = language;
	}

	public String getLocale() {
		return locale;
	}

	public void setLocale(String locale) {
		this.locale = locale;
	}

	public String getOpenId() {
		return openId;
	}

	public void setOpenId(String openId) {
		this.openId = openId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	@Override
	public void validate() throws SubscritonException {
	}

	public static void main(String a[]) throws JsonGenerationException, JsonMappingException,
			IOException {
		CreatorRequest req = new CreatorRequest();
		req.addr = req.new Address();

		ObjectMapper mapper = new ObjectMapper();
		System.out.println(mapper.writeValueAsString(req));
	}

}
