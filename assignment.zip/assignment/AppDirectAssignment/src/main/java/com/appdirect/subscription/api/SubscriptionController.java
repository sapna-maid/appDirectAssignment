package com.appdirect.subscription.api;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import oauth.signpost.basic.DefaultOAuthConsumer;
import oauth.signpost.exception.OAuthCommunicationException;
import oauth.signpost.exception.OAuthExpectationFailedException;
import oauth.signpost.exception.OAuthMessageSignerException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.appdirect.subscription.constants.SubscriptionConstants;
import com.appdirect.subscription.exception.SubscritonException;
import com.appdirect.subscription.request.SubscriptionCancelRequest;
import com.appdirect.subscription.request.SubscriptionCreateRequest;
import com.appdirect.subscription.response.APIResponse;
import com.appdirect.subscription.response.SubscriptionResponse;
import com.appdirect.subscription.service.SubscriptionService;

@Controller
@RequestMapping("/subscription")
public class SubscriptionController {

	@Autowired
	private SubscriptionService subscriptionService;

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public @ResponseBody
	APIResponse createSubscriptionEvent(@RequestParam("eventUrl") String eventUrl) {
		System.out.println("Create subscription event: " + eventUrl);
		return this.signReqsuest(eventUrl);
	}

	private APIResponse signReqsuest(String eventUrl) {
		APIResponse apiResponse = new APIResponse();
		DefaultOAuthConsumer consumer = new DefaultOAuthConsumer(SubscriptionConstants.API_KEY,
				SubscriptionConstants.API_SECRET);
		URL url;
		try {
			url = new URL(eventUrl);
			HttpURLConnection request = (HttpURLConnection) url.openConnection();
			consumer.sign(request);
			request.connect();
		} catch (MalformedURLException e) {
			apiResponse.setSuccess(false);
		} catch (OAuthMessageSignerException | OAuthExpectationFailedException
				| OAuthCommunicationException e) {
			apiResponse.setSuccess(false);
		} catch (IOException e) {
			apiResponse.setSuccess(false);
		}
		return apiResponse;
	}

	@RequestMapping(value = "/change", method = RequestMethod.GET)
	public @ResponseBody
	APIResponse changeSubscriptionEvent(@RequestParam("eventUrl") String eventUrl) {
		System.out.println("Change subscription event: " + eventUrl);
		return this.signReqsuest(eventUrl);
	}

	@RequestMapping(value = "/cancel", method = RequestMethod.GET)
	public @ResponseBody
	APIResponse cancelSubscriptionEvent(@RequestParam("eventUrl") String eventUrl) {
		System.out.println("Cancel subscription event: " + eventUrl);
		return this.signReqsuest(eventUrl);
	}

	@RequestMapping(value = "/status", method = RequestMethod.GET)
	public @ResponseBody
	APIResponse statusSubscriptionEvent(@RequestParam("eventUrl") String eventUrl) {
		System.out.println("Status subscription event: " + eventUrl);
		return this.signReqsuest(eventUrl);
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public @ResponseBody
	SubscriptionResponse createSubscription(
			@RequestBody SubscriptionCreateRequest subscriptionCreateRequest)
			throws SubscritonException {
		SubscriptionResponse apiResponse = subscriptionService
				.createSubscription(subscriptionCreateRequest);
		return apiResponse;

	}

	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public @ResponseBody
	SubscriptionResponse updateSubscription(
			@RequestBody SubscriptionCreateRequest subscriptionCreateRequest)
			throws SubscritonException {
		SubscriptionResponse apiResponse = subscriptionService
				.updateSubscription(subscriptionCreateRequest);
		return apiResponse;

	}

	@RequestMapping(value = "/cancel", method = RequestMethod.POST)
	public @ResponseBody
	APIResponse cancelSubscription(@RequestBody SubscriptionCancelRequest subscriptionCancelRequest)
			throws SubscritonException {
		APIResponse apiResponse = subscriptionService.cancelSubscription(subscriptionCancelRequest);
		return apiResponse;

	}

}
