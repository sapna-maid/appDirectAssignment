package com.appdirect.subscription.constants;

public class SubscriptionConstants {

	public static final String CREATE = "/create";

	public static final String ORDER = "ORDER";
	public static final String COMPANY = "COMPANY";
	public static final String CREATER = "CREATER";
	public static final String MARKET_PLACE = "MARKETPLACE";
	public static final String SUBSCRIPTION = "SUBSCRIPTION";

	public static final String API_SECRET = "XJ6mcmmRpRYO";
	public static final String API_KEY = "sapnamaidtest-137132";

}
