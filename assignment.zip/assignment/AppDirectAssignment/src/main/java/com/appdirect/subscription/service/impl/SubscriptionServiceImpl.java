package com.appdirect.subscription.service.impl;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.appdirect.subscription.constants.SubscriptionConstants;
import com.appdirect.subscription.constants.SubscriptionError;
import com.appdirect.subscription.converter.SubscriptionConverter;
import com.appdirect.subscription.dao.SubscriptionDAO;
import com.appdirect.subscription.exception.SubscritonException;
import com.appdirect.subscription.orm.Company;
import com.appdirect.subscription.orm.Creater;
import com.appdirect.subscription.orm.MarketPlace;
import com.appdirect.subscription.orm.Subscription;
import com.appdirect.subscription.request.CreatorRequest;
import com.appdirect.subscription.request.SubscriptionCancelRequest;
import com.appdirect.subscription.request.SubscriptionCreateRequest;
import com.appdirect.subscription.response.APIResponse;
import com.appdirect.subscription.response.SubscriptionResponse;
import com.appdirect.subscription.service.SubscriptionService;

/**
 * @author sapna
 * 
 */
@Service
public class SubscriptionServiceImpl implements SubscriptionService {

	private SubscriptionDAO subscriptionDAO;

	public SubscriptionDAO getSubscriptionDAO() {
		return subscriptionDAO;
	}

	public void setSubscriptionDAO(SubscriptionDAO subscriptionDAO) {
		this.subscriptionDAO = subscriptionDAO;
	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public SubscriptionResponse createSubscription(
			SubscriptionCreateRequest subscriptionCreateRequest) throws SubscritonException {
		SubscriptionResponse apiResponse = new SubscriptionResponse();
		try {
			subscriptionCreateRequest.validate();
			// Get company ORM out of request

			Subscription subscription = new Subscription();
			subscription.setType(subscriptionCreateRequest.getType());

			if (null != subscriptionCreateRequest.getPayload()
					&& null != subscriptionCreateRequest.getPayload().getCompany()) {
				Company company = SubscriptionConverter.toCompanyORM(subscriptionCreateRequest
						.getPayload().getCompany());
				int companyId = subscriptionDAO.save(company);
				Company companySaved = (Company) subscriptionDAO.getEntity(companyId,
						SubscriptionConstants.COMPANY);
				subscription.setCompany(companySaved);
			}
			if (null != subscriptionCreateRequest.getMarketplace()) {
				MarketPlace marketPlace = SubscriptionConverter
						.toMarketPlaceORM(subscriptionCreateRequest.getMarketplace());
				int marketPlaceId = subscriptionDAO.save(marketPlace);
				MarketPlace marketPlaceSaved = (MarketPlace) subscriptionDAO.getEntity(
						marketPlaceId, SubscriptionConstants.MARKET_PLACE);
				subscription.setMarketPlace(marketPlaceSaved);
			}
			if (null != subscriptionCreateRequest.getCreator()) {
				int createrId = this.saveCreator(subscriptionCreateRequest.getCreator());
				Creater createrSaved = (Creater) subscriptionDAO.getEntity(createrId,
						SubscriptionConstants.CREATER);
				subscription.setCreator(createrSaved);
			}
			// Save Subscription
			subscriptionDAO.save(subscription);

		} catch (Exception e) {
			apiResponse.setErrorCode(SubscriptionError.SUBSCRIPTION_CREATE_FAILED);
			apiResponse.setSuccess(false);
		}
		return apiResponse;
	}

	private int saveCreator(CreatorRequest creatorRequest) throws SubscritonException {
		creatorRequest.validate();
		Creater creater = SubscriptionConverter.toCreatorORM(creatorRequest);
		return subscriptionDAO.save(creater);
	}

	@Override
	public SubscriptionResponse updateSubscription(
			SubscriptionCreateRequest subscriptionCreateRequest) throws SubscritonException {
		// TODO: Update subscription
		return new SubscriptionResponse();
	}

	@Override
	@Transactional(rollbackOn = Exception.class)
	public APIResponse cancelSubscription(SubscriptionCancelRequest subscriptionCancelRequest)
			throws SubscritonException {
		subscriptionCancelRequest.validate();
		// Search subscription which needs to be cancelled.

		Subscription subscription = (Subscription) subscriptionDAO.getEntity(
				subscriptionCancelRequest.getSubscriptionId(), SubscriptionConstants.SUBSCRIPTION);
		// Delete subscription mappings
		subscriptionDAO.delete(subscription.getCompany());
		subscriptionDAO.delete(subscription.getCreator());
		subscriptionDAO.delete(subscription.getMarketPlace());
		subscriptionDAO.delete(subscription.getOrder());
		// Now delete subscription
		subscriptionDAO.delete(subscription);

		return new APIResponse();
	}

}
