package com.appdirect.subscription.dao.impl;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.appdirect.subscription.dao.GenericDAO;

@Repository
public abstract class GenericDAOImpl implements GenericDAO {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	@Transactional
	public <T> int save(T object) {
		Session session = sessionFactory.getCurrentSession();
		Integer id = (Integer) session.save(object);
		return id;
	}

	@Override
	@Transactional
	public <T> void delete(T object) {
		Session session = sessionFactory.getCurrentSession();
		session.delete(object);

	}

}
