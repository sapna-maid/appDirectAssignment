package com.appdirect.subscription.constants;

public class SubscriptionError {

	public static final String INVALID_COMPANY_NAME = "Company name is invalid.";
	public static final String COMPANY_PAYLOAD_REQUITRED = "Subscription request company details are empty.";
	public static final String SUBSCRIPTION_CREATE_FAILED = "subscription create failed.";
	public static final String SUBSCRIPTION_ID_INVALID = "Subscription id is invalid.";

}
