package com.appdirect.subscription.constants;

public enum Language {
	EN
}
