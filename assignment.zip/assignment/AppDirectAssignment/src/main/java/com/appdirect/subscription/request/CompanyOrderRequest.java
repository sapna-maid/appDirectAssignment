package com.appdirect.subscription.request;

import java.io.Serializable;

import com.appdirect.subscription.constants.AccountStatus;
import com.appdirect.subscription.constants.NoticeType;
import com.appdirect.subscription.constants.OrderUnit;
import com.appdirect.subscription.constants.PricingDuration;

public class CompanyOrderRequest extends APIRequest {

	private static final long serialVersionUID = 1L;

	public class Company implements Serializable {
		private static final long serialVersionUID = 1L;
		private String country;
		private String name;
		private String phoneNumber;
		private String uuid;
		private String website;

		public String getCountry() {
			return country;
		}

		public void setCountry(String country) {
			this.country = country;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getPhoneNumber() {
			return phoneNumber;
		}

		public void setPhoneNumber(String phoneNumber) {
			this.phoneNumber = phoneNumber;
		}

		public String getUuid() {
			return uuid;
		}

		public void setUuid(String uuid) {
			this.uuid = uuid;
		}

		public String getWebsite() {
			return website;
		}

		public void setWebsite(String website) {
			this.website = website;
		}

	}

	private Company company;

	public class Order implements Serializable {
		private static final long serialVersionUID = 1L;
		private String editionCode;
		private PricingDuration pricingDuration;

		public class Item implements Serializable {

			private static final long serialVersionUID = 1L;
			private int quantity;
			private OrderUnit unit;

			public int getQuantity() {
				return quantity;
			}

			public void setQuantity(int quantity) {
				this.quantity = quantity;
			}

			public OrderUnit getUnit() {
				return unit;
			}

			public void setUnit(OrderUnit unit) {
				this.unit = unit;
			}

		}

		private Item item;

		public String getEditionCode() {
			return editionCode;
		}

		public void setEditionCode(String editionCode) {
			this.editionCode = editionCode;
		}

		public PricingDuration getPricingDuration() {
			return pricingDuration;
		}

		public void setPricingDuration(PricingDuration pricingDuration) {
			this.pricingDuration = pricingDuration;
		}

		public Item getItem() {
			return item;
		}

		public void setItem(Item item) {
			this.item = item;
		}

	}

	public class Account implements Serializable {

		private static final long serialVersionUID = 1L;
		private String accountIdentifier;
		private AccountStatus status;

		public String getAccountIdentifier() {
			return accountIdentifier;
		}

		public void setAccountIdentifier(String accountIdentifier) {
			this.accountIdentifier = accountIdentifier;
		}

		public AccountStatus getStatus() {
			return status;
		}

		public void setStatus(AccountStatus status) {
			this.status = status;
		}

	}

	private NoticeType notice;

	private Order order;

	private Account account;

	public NoticeType getNotice() {
		return notice;
	}

	public void setNotice(NoticeType notice) {
		this.notice = notice;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

}
