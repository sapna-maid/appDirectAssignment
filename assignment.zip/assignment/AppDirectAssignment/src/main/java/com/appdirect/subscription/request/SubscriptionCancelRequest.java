package com.appdirect.subscription.request;

import java.util.ArrayList;
import java.util.List;

import com.appdirect.subscription.constants.SubscriptionError;
import com.appdirect.subscription.exception.SubscritonException;

public class SubscriptionCancelRequest extends APIRequest {

	private static final long serialVersionUID = 1L;

	private int subscriptionId;

	public int getSubscriptionId() {
		return subscriptionId;
	}

	public void setSubscriptionId(int subscriptionId) {
		this.subscriptionId = subscriptionId;
	}

	@Override
	public void validate() throws SubscritonException {
		List<String> errors = new ArrayList<String>();
		if (this.getSubscriptionId() <= 0) {
			errors.add(SubscriptionError.SUBSCRIPTION_ID_INVALID);
		}
		if (null != errors && errors.size() > 0) {
			throw new SubscritonException(errors);
		}
	}

}
