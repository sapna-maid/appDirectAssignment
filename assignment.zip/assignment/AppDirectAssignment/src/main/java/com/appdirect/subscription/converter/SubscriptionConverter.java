package com.appdirect.subscription.converter;

import com.appdirect.subscription.orm.Company;
import com.appdirect.subscription.orm.Creater;
import com.appdirect.subscription.orm.MarketPlace;
import com.appdirect.subscription.request.CreatorRequest;
import com.appdirect.subscription.request.MarketplaceRequest;

public class SubscriptionConverter {

	public static Company toCompanyORM(
			com.appdirect.subscription.request.CompanyOrderRequest.Company companyRequest) {
		Company company = new Company();
		company.setCompanyName(companyRequest.getName());
		company.setCountry(companyRequest.getCountry());
		company.setPh_number(companyRequest.getPhoneNumber());
		company.setUuid(companyRequest.getUuid());
		company.setWebsite(companyRequest.getWebsite());
		return company;
	}

	public static MarketPlace toMarketPlaceORM(MarketplaceRequest marketplaceRequest) {
		MarketPlace marketPlace = new MarketPlace();
		marketPlace.setBaseUrl(marketplaceRequest.getBaseUrl());
		if (null != marketplaceRequest.getPartner()) {
			marketPlace.setPartner(marketplaceRequest.getPartner());
		}
		return marketPlace;
	}

	public static Creater toCreatorORM(CreatorRequest creatorRequest) {
		Creater creater = new Creater();
		if (null != creatorRequest.getAddr()) {
			StringBuilder addr = new StringBuilder(creatorRequest.getAddr().getFirstName()
					.concat(creatorRequest.getAddr().getLastName())
					.concat(creatorRequest.getAddr().getFullName()));
			creater.setAddress(addr.toString());
		}

		creater.setFirstName(creatorRequest.getFirstName());
		creater.setLanguage(creatorRequest.getLanguage());
		creater.setLastName(creatorRequest.getLastName());
		creater.setLocale(creatorRequest.getLocale());
		creater.setOpenId(creatorRequest.getOpenId());
		creater.setUuid(creatorRequest.getUuid());
		return null;
	}

}
