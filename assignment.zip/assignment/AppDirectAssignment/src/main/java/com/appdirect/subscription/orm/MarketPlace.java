package com.appdirect.subscription.orm;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.appdirect.subscription.constants.Partner;

@Entity
@Table(name = "marketplace")
public class MarketPlace implements GenericORM {
	
	@Id
	@GeneratedValue
	@Column(name = "marketplace_id")
	private Integer marketplaceId;

	@Column(name = "base_url")
	private String baseUrl;

	@Column(name = "partner")
	private Partner partner;

	public Integer getMarketplaceId() {
		return marketplaceId;
	}

	public void setMarketplaceId(Integer marketplaceId) {
		this.marketplaceId = marketplaceId;
	}

	public String getBaseUrl() {
		return baseUrl;
	}

	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}

	public Partner getPartner() {
		return partner;
	}

	public void setPartner(Partner partner) {
		this.partner = partner;
	}

}