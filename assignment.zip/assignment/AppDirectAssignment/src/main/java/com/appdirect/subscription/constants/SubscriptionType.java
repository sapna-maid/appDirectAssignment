package com.appdirect.subscription.constants;

public enum SubscriptionType {
	FREE_TRIAL, ACTIVE;
}
